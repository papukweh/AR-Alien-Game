Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - pgi ( https://freesound.org/people/pgi/ )

You can find this pack online at: https://freesound.org/people/pgi/packs/13493/

License details
---------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 212608__pgi__machine-gun-002-loop.ogg
    * url: https://freesound.org/s/212608/
    * license: Creative Commons 0
  * 212607__pgi__machine-gun-002-single-shot.ogg
    * url: https://freesound.org/s/212607/
    * license: Creative Commons 0
  * 212606__pgi__machine-gun-002-triple-shot.ogg
    * url: https://freesound.org/s/212606/
    * license: Creative Commons 0


