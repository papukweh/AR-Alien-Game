Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - jobro ( https://freesound.org/people/jobro/ )

You can find this pack online at: https://freesound.org/people/jobro/packs/2269/

License details
---------------

Attribution: http://creativecommons.org/licenses/by/3.0/


Sounds in this pack
-------------------

  * 35686__jobro__Laser9.wav
    * url: https://freesound.org/s/35686/
    * license: Attribution
  * 35685__jobro__Laser8.wav
    * url: https://freesound.org/s/35685/
    * license: Attribution
  * 35684__jobro__Laser7.wav
    * url: https://freesound.org/s/35684/
    * license: Attribution
  * 35683__jobro__Laser6.wav
    * url: https://freesound.org/s/35683/
    * license: Attribution
  * 35682__jobro__Laser5.wav
    * url: https://freesound.org/s/35682/
    * license: Attribution
  * 35681__jobro__Laser4.wav
    * url: https://freesound.org/s/35681/
    * license: Attribution
  * 35680__jobro__Laser3.wav
    * url: https://freesound.org/s/35680/
    * license: Attribution
  * 35679__jobro__Laser2.wav
    * url: https://freesound.org/s/35679/
    * license: Attribution
  * 35678__jobro__Laser10.wav
    * url: https://freesound.org/s/35678/
    * license: Attribution
  * 35677__jobro__Laser1.wav
    * url: https://freesound.org/s/35677/
    * license: Attribution


