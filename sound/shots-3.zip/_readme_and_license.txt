Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - deleted_user_3544904 ( https://freesound.org/people/deleted_user_3544904/ )

You can find this pack online at: https://freesound.org/people/deleted_user_3544904/packs/12150/

License details
---------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 234619__fridobeck__war-machinegun-shooting-005.wav
    * url: https://freesound.org/s/234619/
    * license: Attribution
  * 234618__fridobeck__war-machinegun-shooting-001.wav
    * url: https://freesound.org/s/234618/
    * license: Attribution
  * 234617__fridobeck__war-machinegun-shooting-002.wav
    * url: https://freesound.org/s/234617/
    * license: Attribution
  * 234616__fridobeck__war-machinegun-shooting-003.wav
    * url: https://freesound.org/s/234616/
    * license: Attribution
  * 234615__fridobeck__machinegun-shooting-004.wav
    * url: https://freesound.org/s/234615/
    * license: Attribution
  * 212684__fridobeck__firework-explosion-4.wav
    * url: https://freesound.org/s/212684/
    * license: Creative Commons 0
  * 212683__fridobeck__firework-explosion-3.wav
    * url: https://freesound.org/s/212683/
    * license: Creative Commons 0
  * 212682__fridobeck__firework-explosion-2.wav
    * url: https://freesound.org/s/212682/
    * license: Creative Commons 0
  * 212681__fridobeck__firework-explosions-distance-3.wav
    * url: https://freesound.org/s/212681/
    * license: Creative Commons 0
  * 212680__fridobeck__firework-explosions-distance-2.wav
    * url: https://freesound.org/s/212680/
    * license: Creative Commons 0
  * 212679__fridobeck__firework-explosions-distance-1.wav
    * url: https://freesound.org/s/212679/
    * license: Creative Commons 0
  * 212678__fridobeck__firework-explosion-1.wav
    * url: https://freesound.org/s/212678/
    * license: Creative Commons 0
  * 191694__fridobeck__explosion-4.wav
    * url: https://freesound.org/s/191694/
    * license: Attribution Noncommercial
  * 191693__fridobeck__explosion-3.wav
    * url: https://freesound.org/s/191693/
    * license: Attribution Noncommercial
  * 191692__fridobeck__explosion-2.wav
    * url: https://freesound.org/s/191692/
    * license: Attribution Noncommercial
  * 191691__fridobeck__explosion-1.wav
    * url: https://freesound.org/s/191691/
    * license: Attribution Noncommercial


