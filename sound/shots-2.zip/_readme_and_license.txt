Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - Tito Lahaye ( https://freesound.org/people/Tito%20Lahaye/ )

You can find this pack online at: https://freesound.org/people/Tito%20Lahaye/packs/4927/

License details
---------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 200460__tito-lahaye__22-multiple-shots.wav
    * url: https://freesound.org/s/200460/
    * license: Creative Commons 0
  * 106955__Tito_Lahaye__45_Smith_Wesson_II.wav
    * url: https://freesound.org/s/106955/
    * license: Attribution Noncommercial
  * 86278__Tito_Lahaye__12_gauge_shot_gun.wav
    * url: https://freesound.org/s/86278/
    * license: Attribution Noncommercial
  * 84254__Tito_Lahaye__45_Smith_Wesson.wav
    * url: https://freesound.org/s/84254/
    * license: Attribution Noncommercial
  * 77247__Tito_Lahaye__Mauser_3.08_load_and_shot.wav
    * url: https://freesound.org/s/77247/
    * license: Attribution Noncommercial
  * 77246__Tito_Lahaye__Mauser_3.08_2.wav
    * url: https://freesound.org/s/77246/
    * license: Attribution Noncommercial
  * 76094__Tito_Lahaye__45_2_shots_distant.wav
    * url: https://freesound.org/s/76094/
    * license: Attribution Noncommercial
  * 76093__Tito_Lahaye__45_pistol_load_2_shots.wav
    * url: https://freesound.org/s/76093/
    * license: Attribution Noncommercial
  * 76092__Tito_Lahaye__45_load_and_misfire.wav
    * url: https://freesound.org/s/76092/
    * license: Attribution Noncommercial
  * 76091__Tito_Lahaye__22_rifle_multiple_shots.wav
    * url: https://freesound.org/s/76091/
    * license: Attribution Noncommercial
  * 76090__Tito_Lahaye__22_rifle_2_shots.wav
    * url: https://freesound.org/s/76090/
    * license: Attribution Noncommercial
  * 76089__Tito_Lahaye__22_rifle_1_shot.wav
    * url: https://freesound.org/s/76089/
    * license: Attribution Noncommercial


